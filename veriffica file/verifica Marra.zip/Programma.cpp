//Gabriele Marra 5Binf
//27/01/2025
#include <iostream>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <conio.h>
#include "windows.h"
#include <ctime>
#include "miefunzioni.cpp"
using namespace std;
	
FILE *fp, *app;	
char classe, nomeFile[13];
int nth, nRec, occor=0;

struct record      //dichiarazione del tracciato record
{ char tiporec;
  int   Matricola;
  char CogNome[35];
  char  Sesso;
  char DataNasc[11]; 
  char ComuneRes[25];
  char Classif;
}abbonato;   //abbonato � una variabile strutturata  "Tracciato Record"
record abbonati[20];

int ctrlClasse(char classe); 	//restituisce 0 se errato, 1 se corretto
void intesta();					//scrive su file sequenziale l'intestazione
void lettura();					//Legge e inserisce su un vettore i record desiderati
void scrittura();				//scrive i record su file sequenziale
void scambio();
void ordinamento();


int main(int argn, char* argc[])
{	impVideo();
	if(argn!=3) //controlloo sui parametri
	{	gotoxy(5,5);printf("PARAMETRI AL MAIN NON INSERITI");
		gotoxy(5,5);printf("\t nomeFile.seq  - nThread    ");
		gotoxy(0,22);
		return 0;
	}//trasferimento dei parametri in variabili
	strcpy(nomeFile,argc[1]);
	nth = atoi(argc[2]);
	
	do{
		gotoxy(0,5);printf("Inserire la classe desiderata:    ");
		gotoxy(0,6);printf("\tC => Comune\n");
					printf("\tP => Provincia\n");
					printf("\tI => Italia\n");
					printf("\tE => Estero\n");
		gotoxy(31,5);scanf("%c", &classe);
		classe=UpChar(classe);
		//stampa messaggio di errore
		if(!ctrlClasse(classe)){
			gotoxy(3,23);printf("Classe inserita non accettata");
		}else{
			gotoxy(3,23);printf("                             ");
		}	
	}while(!ctrlClasse(classe));
	
	intesta(); 		//scrive l'intestazione nel file
	lettura(); 		//trasferisce su vettore i record desiderati
	ordinamento();
	scrittura();	//scrittura su file sequenziale
	
	
	
    gotoxy(0,25);
    return 0;
}


int ctrlClasse(char classe){
	int flag;
	if(classe=='C'||classe=='P'||classe=='I'||classe=='E')
		flag=1;
	else
		flag=0;
	return flag;
}

void intesta()
{	fp=fopen(nomeFile, "w"); //apertura file in scrittura
	//stampa intestazione
	fprintf(fp,"Marra\n\n"); 
	fprintf(fp,"\tELENCO ABBONATI RELATIVI ALLA CLASSIF. %c\n\n", classe);
	fprintf(fp,"N�|Matr| Cognome/Nome                       | Comune                   |cl.|\n");
	fprintf(fp,"==|====|====================================|==========================|===|\n");
	fclose(fp); //chiusura del file
}

void lettura(){
	fp=fopen("Abbonati.txt","r+");
	//LETTURA NUMERO DI RECORD SELEZIONATI
	fseek(fp,sizeof(abbonato),SEEK_END); //posizionamento alla fine del file
	nRec= ftell(fp)/sizeof(abbonato); //acquisimento numero di record nel file diretto
	for(int i=0;i<nRec-1;i++)
	{	fseek(fp,sizeof(abbonato)*i,SEEK_SET);
		fread(&abbonato,sizeof(abbonato),1,fp);
		if(abbonato.Classif==classe && abbonato.tiporec=='A')
		{	abbonati[occor]=abbonato;
			occor++;
			//gotoxy(0,10+occor);printf("ciao %d",abbonati[occor].Matricola);
			//getch();
		}
	}
	fclose(fp);
}

void scrittura(){
	fp=fopen(nomeFile,"a");
	
	for(int i=0; i<occor; i++)
	{	fprintf(fp,"%2d|%3d | %-35s| %-25s| %c |\n", i+1, abbonati[i].Matricola,abbonati[i].CogNome,abbonati[i].ComuneRes, abbonati[i].Classif);
	}
	
	fclose(fp);
}

void scambio(int i, int j){
	record app;
	app=abbonati[i];
	abbonati[i]=abbonati[j];
	abbonati[j]=app;
}

void ordinamento(){
	char nom1[35], nom2[35], app[35];
	for(int i=0; i<occor-1;i++)
	{	for(int j=i+1; j<occor; j++){
			/*poscar=cercaPos(abbonati[i].CogNome,'/');
			SubStr(abbonati[i].CogNome,0,poscar,nom1);
			SubStr(abbonati[i].CogNome,poscar,strlen(abbonati[i].CogNome),app);
*/
			if(strcmp(abbonati[i].CogNome,abbonati[j].CogNome)>0) scambio(i,j);//confronto e richiamo funzione
		}
	}
}








